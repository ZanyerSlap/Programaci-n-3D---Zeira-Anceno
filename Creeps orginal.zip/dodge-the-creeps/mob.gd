extends RigidBody2D

@onready var flicker_timer = $FlickerTimer

func _ready():
	# Seleccionar animación aleatoria
	var mob_types = Array($AnimatedSprite2D.sprite_frames.get_animation_names())
	$AnimatedSprite2D.animation = mob_types.pick_random()
	$AnimatedSprite2D.play()
	
	# Configurar el timer para parpadear
	flicker_timer.wait_time = 0.5
	# Conectar la señal (si no lo está ya)
	if not flicker_timer.timeout.is_connected(_on_flicker_timeout):
		flicker_timer.timeout.connect(_on_flicker_timeout)
	
	# Iniciar con un pequeño retraso aleatorio (0 a 0.3s) para desincronizar
	flicker_timer.start(randf_range(0.2, 0.8))

func _on_flicker_timeout():
	# Si quieres que solo el sprite parpadee, usa:
	$AnimatedSprite2D.visible = not $AnimatedSprite2D.visible

func _on_VisibilityNotifier2D_screen_exited():
	queue_free()
